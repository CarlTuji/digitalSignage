<?php
  echo _("Good Morning");
?>
